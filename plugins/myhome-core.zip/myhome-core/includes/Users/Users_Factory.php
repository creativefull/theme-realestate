<?php

namespace MyHomeCore\Users;


/**
 * Class Users_Factory
 * @package MyHomeCore\Users
 */
class Users_Factory {

	/**
	 * @param int   $limit
	 * @param bool  $exclude_admins
	 * @param array $include
	 *
	 * @return array
	 * @throws \ErrorException
	 */
	public static function get_agents( $limit = - 1, $exclude_admins = true, $include = array() ) {
		$roles = array(
			'agent'
		);
		if ( ! $exclude_admins ) {
			$roles[] = 'administrator';
		}

		$data = array(
			'role__in' => $roles,
			'number'   => $limit
		);

		if ( ! empty( $include ) ) {
			$data['include'] = $include;
		}

		$users = get_users( $data );


		$agents = array();
		foreach ( $users as $user ) {
			$agents[] = User::get_instance( $user );
		}

		usort( $agents, function ( $a, $b ) use ( $include ) {
			$pos_a = array_search( $a->get_ID(), $include );
			$pos_b = array_search( $b->get_ID(), $include );

			return $pos_a - $pos_b;
		} );

		return $agents;
	}

	/**
	 * @return User
	 */
	public static function get_current() {
		$user_id = get_current_user_id();

		return User::get_instance( $user_id );
	}

}