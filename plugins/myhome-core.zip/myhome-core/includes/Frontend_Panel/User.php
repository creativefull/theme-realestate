<?php

namespace Frontend_Panel;


use MyHomeCore\Estates\Estate_Factory;

/**
 * Class User
 * @package Frontend_Panel
 */
class User {

	/**
	 * @var \WP_User
	 */
	private $user;

	/**
	 * User constructor.
	 *
	 * @param \WP_User $user
	 */
	public function __construct( \WP_User $user ) {
		$this->user = $user;
	}

	/**
	 * @return int
	 */
	public function get_ID() {
		return $this->user->ID;
	}

	/**
	 * @return array
	 */
	public function get_data() {
		$data = array(
			'ID'         => $this->user->ID,
			'name'       => $this->user->nickname,
			'email'      => $this->user->user_email,
			'properties' => array()
		);

		$estates_factory = new Estate_Factory();
		$estates_factory->set_user_id( $this->user->ID );
		$estates_factory->set_status( array( 'any' ) );
		foreach ( $estates_factory->get_results() as $estate ) {
			$data['properties'][] = $estate->get_full_data();
		}

		return $data;
	}

	/**
	 * @return bool
	 */
	public function is_confirmed() {
		$is_confirmed = get_user_meta( $this->user->ID, 'myhome_agent_confirmed', true );

		return ! empty( $is_confirmed );
	}

	/**
	 * @return User
	 */
	public static function get_current() {
		$wp_user = wp_get_current_user();

		return new User( $wp_user );
	}
}