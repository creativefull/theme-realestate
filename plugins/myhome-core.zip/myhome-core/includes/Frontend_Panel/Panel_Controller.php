<?php

namespace Frontend_Panel;


/**
 * Class Panel_Controller
 * @package Frontend_Panel
 */
class Panel_Controller {

	/**
	 * Panel_Controller constructor.
	 */
	public function __construct() {
		add_action( 'wp_ajax_nopriv_myhome_panel_login', array( $this, 'login' ) );
		add_action( 'wp_ajax_myhome_panel_register', array( $this, 'logout' ) );

		if ( ! empty( \MyHomeCore\My_Home_Core()->settings->props['mh-agent-registration'] ) ) {
			add_action( 'wp_ajax_nopriv_myhome_panel_register', array( $this, 'register' ) );
		}
	}

	public function login() {
		check_ajax_referer( 'myhome_user_panel' );

		if ( empty( $_POST['credentials'] ) || ! isset( $_POST['rememberMe'] ) ) {
			echo json_encode(
				array(
					'success' => false,
					'title'   => esc_html__( 'Authentication failed', 'myhome-core' ),
					'text'    => esc_html__( 'Some data are missing!', 'myhome-core' )
				)
			);

			wp_die();
		}

		$wp_user_login = $_POST['credentials']['login'];

		if ( filter_var( $wp_user_login, FILTER_VALIDATE_EMAIL ) ) {
			$wp_user = get_user_by( 'email', $wp_user_login );
		} else {
			$wp_user = get_user_by( 'login', $wp_user_login );
		}

		if ( is_wp_error( $wp_user ) || ! $wp_user ) {
			echo json_encode(
				array(
					'success' => false,
					'title'   => esc_html__( 'Authentication failed', 'myhome-core' ),
					'text'    => esc_html__( 'Wrong username or password!', 'myhome-core' )
				)
			);

			wp_die();
		}

		$user = new User( $wp_user );

		if (
			! empty( \MyHomeCore\My_Home_Core()->settings->props['mh-agent-registration'] )
			&& ! empty( \MyHomeCore\My_Home_Core()->settings->props['mh-agent-email_confirmation'] )
			&& ! $user->is_confirmed()
		) {
			echo json_encode(
				array(
					'success'                 => false,
					'title'                   => esc_html__( 'Authentication failed', 'myhome-core' ),
					'text'                    => esc_html__( 'Account isn\'t active. Check your mailbox for activation link.', 'myhome-core' ),
					'request_activation_link' => admin_url( 'admin-ajax.php?action=mh_agent_send_link&uid=' . $user->get_ID() )
				)
			);
			wp_die();
		}


		$login_data = array(
			'user_login'    => $_POST['credentials']['login'],
			'user_password' => $_POST['credentials']['password'],
			'remember'      => $_POST['rememberMe']
		);

		$wp_user = wp_signon( $login_data, false );
		if ( is_wp_error( $wp_user ) ) {
			echo json_encode(
				array(
					'success' => false,
					'title'   => esc_html__( 'Authentication failed', 'myhome-core' ),
					'text'    => esc_html__( 'Wrong username or password!', 'myhome-core' )
				)
			);

			wp_die();
		}

		echo json_encode(
			array(
				'success' => true,
				'title'   => esc_html__( 'Login successful', 'myhome-core' ),
				'text'    => esc_html__( sprintf( 'Hello %s', $user->get_name() ), 'myhome-core' ),
				'user'    => $user->get_data(),
				'nonce'   => wp_create_nonce( 'myhome_user_panel_' . $user->get_ID() )
			)
		);
		wp_die();
	}

}